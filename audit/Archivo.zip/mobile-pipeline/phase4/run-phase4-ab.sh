#!/bin/bash
exec 9>/tmp/phase4-bench.lock
if ! flock -n 9; then
  echo "Another Phase4 orchestrator holds the lock; exiting"
  exit 0
fi
set -u
export PATH="/usr/bin:/bin:/opt/homebrew/bin:$PATH"
OUT="/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-gemini/audit/mobile-pipeline/phase4"
INPUT300="/Users/nasserelbacha/Documents/Dinamic sistems/data/imagenes/Pruebas-GPT-Andes/andes_benchmark_300"
cd "/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-gemini/mobile"
log() { echo "[$(date -u +%H:%M:%S)] $*" | tee -a "$OUT/bench-orchestrator.log"; }

adb -s R58N30GNF2T reverse tcp:8081 tcp:8081 || true
adb -s R58N30GNF2T reverse tcp:8000 tcp:8000 || true

log "=== 5x50 C=1 ==="
npm run benchmark:pipeline -- --input "$INPUT300" --device R58N30GNF2T --photos 50 --runs 5 --confirm-full-run --scanner-concurrency 1 --cooldown-ms 5000 --timeout-ms 2400000 > "$OUT/bench-50-c1-console.log" 2>&1
log "EXIT_50_C1=$?"

log "=== 5x50 C=2 ==="
npm run benchmark:pipeline -- --input "$INPUT300" --device R58N30GNF2T --photos 50 --runs 5 --confirm-full-run --scanner-concurrency 2 --cooldown-ms 5000 --timeout-ms 2400000 > "$OUT/bench-50-c2-console.log" 2>&1
log "EXIT_50_C2=$?"

log "=== 2x300 C=1 ==="
npm run benchmark:pipeline -- --input "$INPUT300" --device R58N30GNF2T --photos 300 --runs 2 --confirm-full-run --scanner-concurrency 1 --cooldown-ms 8000 --timeout-ms 3600000 > "$OUT/bench-300-c1-console.log" 2>&1
log "EXIT_300_C1=$?"
C1_DIR=$(ls -td ../audit/mobile-pipeline/benchmark/*/ 2>/dev/null | head -1)
C1_SUMMARY=""
if [ -n "$C1_DIR" ] && [ -f "${C1_DIR}run2-dual-correctness-summary.json" ]; then
  C1_SUMMARY="${C1_DIR}run2-dual-correctness-summary.json"
fi

log "=== 2x300 C=2 ==="
if [ -n "$C1_SUMMARY" ]; then
  npm run benchmark:pipeline -- --input "$INPUT300" --device R58N30GNF2T --photos 300 --runs 2 --confirm-full-run --scanner-concurrency 2 --cooldown-ms 8000 --timeout-ms 3600000 --compare-correctness "$C1_SUMMARY" > "$OUT/bench-300-c2-console.log" 2>&1
else
  npm run benchmark:pipeline -- --input "$INPUT300" --device R58N30GNF2T --photos 300 --runs 2 --confirm-full-run --scanner-concurrency 2 --cooldown-ms 8000 --timeout-ms 3600000 > "$OUT/bench-300-c2-console.log" 2>&1
fi
log "EXIT_300_C2=$?"
log "ALL_BENCHES_DONE"
