# Benchmark

Status: BENCHMARK_COMPLETED

## Durations (ms)

{
  "min": 42489,
  "max": 57605,
  "median": 43087,
  "exportPrepMaxWorkers": 2,
  "scannerConcurrency": 2,
  "dualCorrectness": {
    "totalPhotos": 50,
    "detectionExact": 50,
    "detectionPartial": 0,
    "detectionFalseNegative": 0,
    "detectionUnexpectedExtra": 0,
    "detectionExactAccuracy": 1,
    "detectionRecall": 1,
    "domainExact": 43,
    "correctRejections": 5,
    "falsePositives": 0,
    "falseNegatives": 2,
    "wrongPosition": 0,
    "wrongItem": 0,
    "wrongQuantity": 0,
    "ambiguousExpected": 5,
    "ambiguousCorrect": 0,
    "pipelineErrors": 0,
    "domainExactAccuracy": 0.86,
    "byScenario": {
      "item": {
        "total": 22,
        "detectionExact": 22,
        "domainExact": 22,
        "correctRejections": 0
      },
      "multi_mixed": {
        "total": 5,
        "detectionExact": 5,
        "domainExact": 3,
        "correctRejections": 0
      },
      "position": {
        "total": 13,
        "detectionExact": 13,
        "domainExact": 13,
        "correctRejections": 0
      },
      "multi_false": {
        "total": 5,
        "detectionExact": 5,
        "domainExact": 5,
        "correctRejections": 5
      },
      "multi_true": {
        "total": 5,
        "detectionExact": 5,
        "domainExact": 0,
        "correctRejections": 0
      }
    }
  },
  "note": "Do not treat 5 totals as p95; per-photo percentiles live in events jsonl"
}

## PROFILE RESOLUTION EVIDENCE

```json
{
  "clientId": "8a3c9a01-7494-4be0-99be-595ecbf2b9bd",
  "supplierRouteId": "bce1460e-7238-4e39-82ec-8c4e51dcb9ca",
  "resolvedClientSupplierId": "bce1460e-7238-4e39-82ec-8c4e51dcb9ca",
  "expectedProfile": "andes",
  "resolvedClientId": "8a3c9a01-7494-4be0-99be-595ecbf2b9bd",
  "resolvedSupplierId": "bce1460e-7238-4e39-82ec-8c4e51dcb9ca",
  "resolvedProfileName": "andes",
  "itemProfileVersion": 7,
  "positionProfileVersion": 3,
  "configurationSource": "device_sqlite_offline_recognition",
  "snapshotResolved": true,
  "hostInventoryId": "f00e01a8-1514-46a4-a5b9-711ead486509"
}
```

No performance improvement is claimed in this phase.
