# Smoke comparison (instrumentation validation)

Prior smoke (misclassified instrumentation):
- benchmarkRunId = 0253ee4f-5c6b-4174-b6bf-676d4f24087b
- terminalCount: 3 / expected 3 / pendingJobs 0
- totalPipeline: 6755 ms
- postLastInput: 4448 ms
- POSITION: errorCode=POSITION_LABEL_DETECTED outcome=scanner_technical_error success=false (**bug**)
- ITEM: decoded_accepted ×2
- Defects: fixtureId=null, no zip_entry, csv_write/zip_validation durationMs=0, zip_close≈total_export

Corrected smoke:
- benchmarkRunId = 5fd7fc4c-724a-4c67-a519-5b8016c762f3
- status: COMPLETED
- terminalCount: 3 / expected 3 / pendingJobs 0
- instrumentation: VALIDATED
- failures: none
- eventCount: 63
- POSITION outcomes: n/a
- ITEM outcomes: decoded_accepted, decoded_accepted, decoded_accepted
- total_pipeline_ms: 2122.226883009076
- zip_entry kinds: csv, manifest, photo
- zip_finalize_ms: 6.815653994679451
- zip_validation_ms: 38.92476999759674
- fixtureId_complete: true

**Do not treat timing deltas as performance improvements** — this phase validates measurement only.
