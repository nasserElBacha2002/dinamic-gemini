# Benchmark

Status: SMOKE_PASSED_INSTRUMENTATION_VALIDATED

PROFILE RESOLUTION EVIDENCE

```json
{
  "clientId": "8a3c9a01-7494-4be0-99be-595ecbf2b9bd",
  "supplierRouteId": "bce1460e-7238-4e39-82ec-8c4e51dcb9ca",
  "resolvedClientSupplierId": "bce1460e-7238-4e39-82ec-8c4e51dcb9ca",
  "expectedProfile": "andes",
  "resolvedClientId": "8a3c9a01-7494-4be0-99be-595ecbf2b9bd",
  "resolvedSupplierId": "bce1460e-7238-4e39-82ec-8c4e51dcb9ca",
  "resolvedProfileName": "andes",
  "itemProfileVersion": 7,
  "positionProfileVersion": 3,
  "configurationSource": "device_sqlite_offline_recognition",
  "snapshotResolved": true,
  "hostInventoryId": "f00e01a8-1514-46a4-a5b9-711ead486509"
}
```

## Instrumentation

```json
{
  "eventCount": 63,
  "photoEventCount": 33,
  "zipEntryCount": 5,
  "zipEntryKinds": [
    "csv",
    "manifest",
    "photo"
  ],
  "terminals": [
    {
      "fixtureId": "001_position",
      "outcome": "decoded_accepted",
      "success": true,
      "errorCode": null,
      "durationMs": 1757.965807005763,
      "scannerProcessingMs": 287,
      "photoPipelineWallMs": 1757.965807005763
    },
    {
      "fixtureId": "081_item",
      "outcome": "decoded_accepted",
      "success": true,
      "errorCode": null,
      "durationMs": 1758.2195759862661,
      "scannerProcessingMs": 216,
      "photoPipelineWallMs": 1758.2195759862661
    },
    {
      "fixtureId": "082_item",
      "outcome": "decoded_accepted",
      "success": true,
      "errorCode": null,
      "durationMs": 1758.4310369938612,
      "scannerProcessingMs": 243,
      "photoPipelineWallMs": 1758.4310369938612
    }
  ]
}
```

# Smoke comparison (instrumentation validation)

Prior smoke (misclassified instrumentation):
- benchmarkRunId = 0253ee4f-5c6b-4174-b6bf-676d4f24087b
- terminalCount: 3 / expected 3 / pendingJobs 0
- totalPipeline: 6755 ms
- postLastInput: 4448 ms
- POSITION: errorCode=POSITION_LABEL_DETECTED outcome=scanner_technical_error success=false (**bug**)
- ITEM: decoded_accepted ×2
- Defects: fixtureId=null, no zip_entry, csv_write/zip_validation durationMs=0, zip_close≈total_export

Corrected smoke:
- benchmarkRunId = 5fd7fc4c-724a-4c67-a519-5b8016c762f3
- status: COMPLETED
- terminalCount: 3 / expected 3 / pendingJobs 0
- instrumentation: VALIDATED
- failures: none
- eventCount: 63
- POSITION outcomes: n/a
- ITEM outcomes: decoded_accepted, decoded_accepted, decoded_accepted
- total_pipeline_ms: 2122.226883009076
- zip_entry kinds: csv, manifest, photo
- zip_finalize_ms: 6.815653994679451
- zip_validation_ms: 38.92476999759674
- fixtureId_complete: true

**Do not treat timing deltas as performance improvements** — this phase validates measurement only.


Decision: do not run 5×50 until explicitly requested after this gate.
