# Smoke comparison (instrumentation validation)

Prior smoke (misclassified instrumentation):
- benchmarkRunId = 0253ee4f-5c6b-4174-b6bf-676d4f24087b
- terminalCount: 3 / expected 3 / pendingJobs 0
- totalPipeline: 6755 ms
- postLastInput: 4448 ms
- POSITION: errorCode=POSITION_LABEL_DETECTED outcome=scanner_technical_error success=false (**bug**)
- ITEM: decoded_accepted ×2
- Defects: fixtureId=null, no zip_entry, csv_write/zip_validation durationMs=0, zip_close≈total_export

Corrected smoke:
- benchmarkRunId = cfb325ce-0bca-4000-9032-bb412d70316d
- status: COMPLETED
- terminalCount: 3 / expected 3 / pendingJobs 0
- instrumentation: VALIDATED
- failures: none
- eventCount: 63
- POSITION outcomes: position_detected
- ITEM outcomes: decoded_accepted, decoded_accepted
- total_pipeline_ms: 4175.632727995515
- zip_entry kinds: csv, manifest, photo
- zip_finalize_ms: 4.5195000022649765
- zip_validation_ms: 60.95846199989319
- fixtureId_complete: true

**Do not treat timing deltas as performance improvements** — this phase validates measurement only.
