# Smoke comparison (instrumentation validation)

Prior smoke (misclassified instrumentation):
- benchmarkRunId = 0253ee4f-5c6b-4174-b6bf-676d4f24087b
- terminalCount: 3 / expected 3 / pendingJobs 0
- totalPipeline: 6755 ms
- postLastInput: 4448 ms
- POSITION: errorCode=POSITION_LABEL_DETECTED outcome=scanner_technical_error success=false (**bug**)
- ITEM: decoded_accepted ×2
- Defects: fixtureId=null, no zip_entry, csv_write/zip_validation durationMs=0, zip_close≈total_export

Corrected smoke:
- benchmarkRunId = 5cc5882d-6b34-458d-ba32-96f89f5607d8
- status: COMPLETED
- terminalCount: 3 / expected 3 / pendingJobs 0
- instrumentation: VALIDATED
- failures: none
- eventCount: 63
- POSITION outcomes: position_detected
- ITEM outcomes: decoded_accepted, decoded_accepted
- total_pipeline_ms: 3689.2611889988184
- zip_entry kinds: csv, manifest, photo
- zip_finalize_ms: 7.264616012573242
- zip_validation_ms: 42.378769010305405
- fixtureId_complete: true

**Do not treat timing deltas as performance improvements** — this phase validates measurement only.
