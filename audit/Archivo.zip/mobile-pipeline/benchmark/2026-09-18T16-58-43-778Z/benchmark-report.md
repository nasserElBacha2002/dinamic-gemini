# Benchmark

Status: SMOKE_PASSED_INSTRUMENTATION_VALIDATED

PROFILE RESOLUTION EVIDENCE

```json
{
  "clientId": "8a3c9a01-7494-4be0-99be-595ecbf2b9bd",
  "supplierRouteId": "bce1460e-7238-4e39-82ec-8c4e51dcb9ca",
  "resolvedClientSupplierId": "bce1460e-7238-4e39-82ec-8c4e51dcb9ca",
  "expectedProfile": "andes",
  "resolvedClientId": "8a3c9a01-7494-4be0-99be-595ecbf2b9bd",
  "resolvedSupplierId": "bce1460e-7238-4e39-82ec-8c4e51dcb9ca",
  "resolvedProfileName": "andes",
  "itemProfileVersion": 7,
  "positionProfileVersion": 3,
  "configurationSource": "device_sqlite_offline_recognition",
  "snapshotResolved": true,
  "hostInventoryId": "f00e01a8-1514-46a4-a5b9-711ead486509"
}
```

## Instrumentation

```json
{
  "eventCount": 63,
  "photoEventCount": 33,
  "zipEntryCount": 5,
  "zipEntryKinds": [
    "csv",
    "manifest",
    "photo"
  ],
  "terminals": [
    {
      "fixtureId": "001_position",
      "outcome": "decoded_accepted",
      "success": true,
      "errorCode": null,
      "durationMs": 2112.893421009183,
      "scannerProcessingMs": 286,
      "photoPipelineWallMs": 2112.893421009183
    },
    {
      "fixtureId": "081_item",
      "outcome": "decoded_accepted",
      "success": true,
      "errorCode": null,
      "durationMs": 2113.3055750131607,
      "scannerProcessingMs": 280,
      "photoPipelineWallMs": 2113.3055750131607
    },
    {
      "fixtureId": "082_item",
      "outcome": "decoded_accepted",
      "success": true,
      "errorCode": null,
      "durationMs": 2113.76353700459,
      "scannerProcessingMs": 254,
      "photoPipelineWallMs": 2113.76353700459
    }
  ]
}
```

# Smoke comparison (instrumentation validation)

Prior smoke (misclassified instrumentation):
- benchmarkRunId = 0253ee4f-5c6b-4174-b6bf-676d4f24087b
- terminalCount: 3 / expected 3 / pendingJobs 0
- totalPipeline: 6755 ms
- postLastInput: 4448 ms
- POSITION: errorCode=POSITION_LABEL_DETECTED outcome=scanner_technical_error success=false (**bug**)
- ITEM: decoded_accepted ×2
- Defects: fixtureId=null, no zip_entry, csv_write/zip_validation durationMs=0, zip_close≈total_export

Corrected smoke:
- benchmarkRunId = e4b7da95-ec1a-4b73-88cd-a68e8cee48f3
- status: COMPLETED
- terminalCount: 3 / expected 3 / pendingJobs 0
- instrumentation: VALIDATED
- failures: none
- eventCount: 63
- POSITION outcomes: n/a
- ITEM outcomes: decoded_accepted, decoded_accepted, decoded_accepted
- total_pipeline_ms: 2483.3749600052834
- zip_entry kinds: csv, manifest, photo
- zip_finalize_ms: 10.471883997321129
- zip_validation_ms: 47.15530799329281
- fixtureId_complete: true

**Do not treat timing deltas as performance improvements** — this phase validates measurement only.


Decision: do not run 5×50 until explicitly requested after this gate.
