# Smoke comparison (instrumentation validation)

Prior smoke (misclassified instrumentation):
- benchmarkRunId = 0253ee4f-5c6b-4174-b6bf-676d4f24087b
- terminalCount: 3 / expected 3 / pendingJobs 0
- totalPipeline: 6755 ms
- postLastInput: 4448 ms
- POSITION: errorCode=POSITION_LABEL_DETECTED outcome=scanner_technical_error success=false (**bug**)
- ITEM: decoded_accepted ×2
- Defects: fixtureId=null, no zip_entry, csv_write/zip_validation durationMs=0, zip_close≈total_export

Corrected smoke:
- benchmarkRunId = e4b7da95-ec1a-4b73-88cd-a68e8cee48f3
- status: COMPLETED
- terminalCount: 3 / expected 3 / pendingJobs 0
- instrumentation: VALIDATED
- failures: none
- eventCount: 63
- POSITION outcomes: n/a
- ITEM outcomes: decoded_accepted, decoded_accepted, decoded_accepted
- total_pipeline_ms: 2483.3749600052834
- zip_entry kinds: csv, manifest, photo
- zip_finalize_ms: 10.471883997321129
- zip_validation_ms: 47.15530799329281
- fixtureId_complete: true

**Do not treat timing deltas as performance improvements** — this phase validates measurement only.
