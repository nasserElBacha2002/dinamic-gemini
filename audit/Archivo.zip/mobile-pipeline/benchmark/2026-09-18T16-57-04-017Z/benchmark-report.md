# Benchmark

Status: BENCHMARK_COMPLETED

## Durations (ms)

{
  "min": 17687,
  "max": 17687,
  "median": 17687,
  "exportPrepMaxWorkers": 2,
  "scannerConcurrency": 2,
  "dualCorrectness": {
    "totalPhotos": 12,
    "detectionExact": 0,
    "detectionPartial": 0,
    "detectionFalseNegative": 0,
    "detectionUnexpectedExtra": 12,
    "detectionExactAccuracy": 0,
    "detectionRecall": 1,
    "domainExact": 0,
    "correctRejections": 0,
    "falsePositives": 0,
    "falseNegatives": 12,
    "wrongPosition": 0,
    "wrongItem": 0,
    "wrongQuantity": 0,
    "ambiguousExpected": 0,
    "ambiguousCorrect": 0,
    "pipelineErrors": 0,
    "domainExactAccuracy": 0,
    "byScenario": {
      "position": {
        "total": 2,
        "detectionExact": 0,
        "domainExact": 0,
        "correctRejections": 0
      },
      "item": {
        "total": 10,
        "detectionExact": 0,
        "domainExact": 0,
        "correctRejections": 0
      }
    }
  },
  "note": "Do not treat 5 totals as p95; per-photo percentiles live in events jsonl"
}

## PROFILE RESOLUTION EVIDENCE

```json
{
  "clientId": "8a3c9a01-7494-4be0-99be-595ecbf2b9bd",
  "supplierRouteId": "bce1460e-7238-4e39-82ec-8c4e51dcb9ca",
  "resolvedClientSupplierId": "bce1460e-7238-4e39-82ec-8c4e51dcb9ca",
  "expectedProfile": "andes",
  "resolvedClientId": "8a3c9a01-7494-4be0-99be-595ecbf2b9bd",
  "resolvedSupplierId": "bce1460e-7238-4e39-82ec-8c4e51dcb9ca",
  "resolvedProfileName": "andes",
  "itemProfileVersion": 7,
  "positionProfileVersion": 3,
  "configurationSource": "device_sqlite_offline_recognition",
  "snapshotResolved": true,
  "hostInventoryId": "f00e01a8-1514-46a4-a5b9-711ead486509"
}
```

No performance improvement is claimed in this phase.
